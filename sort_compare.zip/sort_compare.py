import random
import time

"""
Swaps 2 values in a list
"""
def swap(lst,index1,index2):
    temp = lst[index1]
    lst[index1] = lst[index2]
    lst[index2] = temp
    return lst

"""
Inserts value into list
"""
def insert (lst , value):
    index = value
    while index > -1 and lst [index] > lst [index + 1]:
        swap (lst , index , index + 1)
        index -= 1

"""
Returns the index of the smallest integer in a list
"""
def findMin(lst, mark):
    minNum = lst[mark]
    index = mark
    counter = mark
    
    while counter < len(lst):
        if lst[counter] < minNum:
            minNum = lst[counter]
            index = counter
        counter += 1
    return index 

"""
Returns a tuple of the even and odd values in lst
"""
def split(lst):
    evens = []
    odds = []
    isEven = True
    for e in lst:
        if isEven:
            evens.append(e)
        else:
            odds.append(e)
        isEven = not isEven
    return(evens, odds)


"""
Merges 2 lists, one containing even values and one containing odd values
"""
def merge(lst1, lst2):
    result = []
    index1 = 0
    index2 = 0
    while index1 < len(lst1) and index2 < len(lst2):
        if lst1[index1] <= lst2[index2]:
            result.append (lst1[index1])
            index1 += 1
        else:
            result.append(lst2[index2])
            index2 += 1
            
    if index1 < len(lst1):
        result.extend(lst1[index1:])
    elif index2 < len(lst2):
        result.extend(lst2[index2:])
    return result

"""
Creates partition from which to sort lst
"""
def partition(pivot, lst):
    (less, same, more) = ([], [], [])
    for e in lst:
        if e < pivot:
            less.append(e)
        elif e > pivot:
            more.append(e)
        else:
            same.append(e)
    return(less ,same ,more)


"""
Sorts a list of integers from smallest to largest
Uses insertion sort algorithm
"""
def insertSort (lst):
    for index in range(len(lst) - 1):
        insert (lst , index)
    return lst
        
"""
Sorts a list of integers from smallest to largest
Uses selection sort algorithm
"""
def selectionSort(lst):
    counter = 0
    while counter < len(lst):
        pos2 = findMin(lst, counter)      
        lst = swap(lst,counter,pos2)
        counter += 1
    return lst

"""
Sorts a list of integers from smallest to largest
Uses heap sort algorithm
"""
def heapSort(lst):
    length = len(lst) - 1
    leastParent = length // 2
    for element in range(leastParent, -1, -1):
        siftDown(lst, element, length)
    
    for element in range(len(lst)-1, 0, -1):
        if lst[0] > lst[element]:
            swap(lst, 0, element)
            siftDown(lst, 0, element-1)
    return lst

"""
Sifts a given element (pos1) of a heap to it's proper spot
"""
def siftDown(lst, pos1, pos2):
    largest = 2 * pos1 + 1
    while largest <= pos2:
        if largest < pos2 and lst[largest] < lst[largest + 1]:
            largest += 1
     
        if lst[largest] > lst[pos1]:
            swap(lst, largest, pos1)
            pos1 = largest
            largest = 2 * pos1 + 1
        else:
            return
    
"""
Sorts a list of integers from smallest to largest
Uses merge sort algorithm
"""
def mergeSort(lst):
    if len(lst) == 0 or len(lst) == 1:
        return lst
    else:
        splitLST = split(lst)
    return merge(mergeSort(splitLST[0]) , mergeSort(splitLST[1]))


"""
Sorts a list of integers from smallest to largest
Uses quick sort algorithm
"""
def quickSort(lst):
    if len(lst) == 0:
        return lst
    else:
        pivot = lst[0]
        (less, same, more) = partition(pivot, lst)
        return quickSort(less) + same + quickSort(more)

"""
Generates a list of random numbers between min and max of size
"""
def generateRandNums(minimum, maximum, size):
    lst = []
    counter = 0
    while counter < size:
        lst.append(random.randint(minimum, maximum))
        counter += 1
    return lst

"""
Prompts user for input, calls and times multiple sort functions on random number list
"""
def main():
    minimum = int(input("What is the min possible value of an item in the list: "))
    maximum = int(input("What is the max possible value of an item in the list: "))
    size = int(input("What is the size of the list: "))

    nums = generateRandNums(minimum, maximum, size)
    
    display = input("Do you want to display the list? (Y/N) ")
    if display == "Y":
        print("The random list is: \n" + str(nums))

    startTime = time.time()
    insertionSorted = insertSort(nums)
    print("Insertion Sort Time: " + str(time.time() - startTime) + " seconds")
    
    startTime = time.time()
    selectionSorted = selectionSort(nums)
    print("Selection Sort Time: " + str(time.time() - startTime) + " seconds")

    startTime = time.time()
    heapSorted = heapSort(nums)
    print("Heap Sort Time: " + str(time.time() - startTime) + " seconds")
    
    startTime = time.time()
    mergeSorted = mergeSort(nums)
    print("Merge Sort Time: " + str(time.time() - startTime) + " seconds")
    
    startTime = time.time()
    quickSorted = quickSort(nums)
    print("Quick Sort Time: " + str(time.time() - startTime) + " seconds")

"""
TEST FUNCTIONS
"""

"""Compares 2 lists and returns whether equal or not"""
def compare(sortedLST, unsortedLST):
    if sortedLST == unsortedLST:
        return True
    else:
        return False
    
"""
Generates sorted and unsorted non-repeating lists
Sorts unsorted using insertion sort algorithm
Tests if equal
""" 
def test_insertion_sort():
    sortedLST = list(range(0,100))
    unsortedLST = random.sample(range(100), 100)
    
    print(compare(sortedLST, insertSort(unsortedLST)))

"""
Generates sorted and unsorted non-repeating lists
Sorts unsorted using selection sort algorithm
Tests if equal
""" 
def test_selection_sort():
    sortedLST = list(range(0,100))
    unsortedLST = random.sample(range(100), 100)
    
    print(compare(sortedLST, selectionSort(unsortedLST)))

"""
Generates sorted and unsorted non-repeating lists
Sorts unsorted using heap sort algorithm
Tests if equal
""" 
def test_heap_sort():
    sortedLST = list(range(0,100))
    unsortedLST = random.sample(range(100), 100)
    
    print(compare(sortedLST, heapSort(unsortedLST)))

"""
Generates sorted and unsorted non-repeating lists
Sorts unsorted using merge sort algorithm
Tests if equal
""" 
def test_merge_sort():
    sortedLST = list(range(0,100))
    unsortedLST = random.sample(range(100), 100)
    
    print(compare(sortedLST, mergeSort(unsortedLST)))

"""
Generates sorted and unsorted non-repeating lists
Sorts unsorted using quick sort algorithm
Tests if equal
""" 
def test_quick_sort():
    sortedLST = list(range(0,100))
    unsortedLST = random.sample(range(100), 100)
    
    print(compare(sortedLST, quickSort(unsortedLST)))

main()

#test_insertion_sort()
#test_selection_sort()
#test_heap_sort()
#test_merge_sort()
#test_quick_sort()

"""
DATA TABLE

LIST SIZE/TIME Insertion,           Selection,           Heap,                  Merge,                 Quick
10             0.0,                 0.0,                 0.0,                   0.0,                   0.0
100            0.0,                 0.0,                 0.0,                   0.0,                   0.0
1,000          0.10084295272827148, 0.08203411102294922, 0.0,                   0.0,                   0.0
10,000         9.638180494308472,   7.887710094451904,   0.06858706474304199,   0.06890702247619629,   0.06900167465209961
100,000        90+,                 90+,                 0.9159502983093262,    0.9189982414245605,    0.6156082153320312
1,000,000      90+,                 90+,                 11.290846109390259,    11.04081654548645,     6.9180192947387695
"""
