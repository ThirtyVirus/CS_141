from tour_utils import *
"""
Brandon Calabrese
"""

"""
Determines if an element is contained in a list
"""
def contains(lst, element):
    for e in lst:
        if e == element:
            return True
    return False

"""
Sorts through a list of places by distance
"""
def sortPlaces(places):
    sortedPlaces = [places[0]]
    
    counter = 1
    currentPlace = places[0]
    while counter < len(places):
        """
        Gets the remaining places
        """
        testPlaces = []
        for place in places:
            if contains(sortedPlaces, place) == False:
                testPlaces.append(place)

        minDistance = -1
        nextLocation = testPlaces[0]
        
        """
        Determines next closest place
        """
        for place in testPlaces:
            testDistance = getDistance(currentPlace.x,currentPlace.y,place.x,place.y)
                
            if (testDistance < minDistance and testDistance != 0) or minDistance < 0:
                minDistance = testDistance
                nextPlace = place
        """
        Adds new place to sorted list
        """
        sortedPlaces.append(nextPlace)
        currentPlace = nextPlace
        counter += 1

    return sortedPlaces

    
def main():
    """
    Gives user instructions and input,
    calls other functions from util file and rest of this file
    """
    initTurtle()
    
    print("+" * 49)
    print("Welcome to the Dippy Hippie Tour. Get on the bus!")
    print("+" * 49)
    
    path = input("Enter filename: ")
    places = getPlaces(path)
    
    print("Reading " + str(path) + " ... " + str(len(places)) + " places.")

    #sort places by distance
    places = sortPlaces(places)
    
    for place in places:
        print(place.name,end = " => " )
    print(places[0].name)
    
    distance = tour(places)

    print("Distance: " + str(distance))
    print("Close the canvas window to quit.")

main()
