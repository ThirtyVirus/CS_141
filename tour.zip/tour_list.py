from tour_utils import *
"""
Brandon Calabrese
"""

def main():
    """
    Gives user instructions and input,
    calls other functions from util file and rest of this file
    """
    initTurtle()
    
    print("+" * 49)
    print("Welcome to the Dippy Hippie Tour. Get on the bus!")
    print("+" * 49)
    
    path = input("Enter filename: ")
    places = getPlaces(path)
    
    print("Reading " + str(path) + " ... " + str(len(places)) + " places.")

    for place in places:
        print(place.name,end = " => " )
    print(places[0].name)

    distance = tour(places)

    print("Distance: " + str(distance))
    print("Close the canvas window to quit.")

main()
