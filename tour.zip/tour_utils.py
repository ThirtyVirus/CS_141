from rit_lib import *
import turtle as t
import math

"""
Brandon Calabrese
"""

"""
Defines a place
"""
class Place(struct):
    _slots = ((str,'name'),(float,'x'),(float,'y'))

"""
Returns the distance between 2 coordinates
"""
def getDistance(x1,y1,x2,y2):
    a = math.pow((x2-x1),2)
    b = math.pow((y2-y1),2)
    return math.sqrt(a + b)

"""
Draws a border on canvas and sets the
turtle's speed and coordinate system
"""
def initTurtle():
    t.setworldcoordinates(0,0,1000,1000)
    t.speed(0)
    
    t.up()
    t.goto(10,10)
    t.down()
    t.goto(990,10)
    t.goto(990,990)
    t.goto(10,990)
    t.goto(10,10)

"""
Grabs a list of places from a file
"""
def getPlaces(path):
    places = []
    myString = open(path)
    
    for line in myString:
        elements = str.split(line,",")
        places.append(Place(elements[0],float(elements[1]),float(elements[2])))
    return places

"""
Loops through the list of places and brings
the turtle there, also draws dots, place names,
and coordinates at each point
"""
def tour(places):
    t.up()
    t.goto(places[0].x,places[0].y)
    t.down()
    
    distance = 0
    counter = 0
    
    for pl in places:

        t.dot()
        t.write(pl.name + " (" + str(round(pl.x,2)) + ", " + str(round(pl.y,2)) + ")")

        if counter < len(places) - 1:
            distance += getDistance(pl.x,pl.y,places[counter + 1].x,places[counter + 1].y)
            t.goto(places[counter + 1].x,places[counter + 1].y)
        else:
            distance += getDistance(pl.x,pl.y,places[0].x,places[0].y)
            t.goto(places[0].x,places[0].y)
            
        counter += 1
    return distance
