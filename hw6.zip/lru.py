from rit_lib import *
"""
Brandon Calabrese - LRU Homework
"""

class LRUEntry(struct):
    _slots = ((str,'page'),(int,'time'))

def put_in_cache(entry, cache):
    """
    Adds new entry to cache in first empty location
    Returns index of new Entry
    Cache must not be full when calling
    """
    
    counter = 0
    while counter < len(cache):
        if cache[counter] == None:
            cache[counter] = LRUEntry(entry,0)
            return counter
        counter += 1

"""
Returns if the cache given is full or not
A cache is full if none of the elements are 'None'
"""
def isCacheFull(cache):
    for element in cache:
        if element == None:
            return False
    return True
    
def position_in_cache(request, cache):
    """
    Returns index of request in cache, if request is not
    in cache then returns cache length
    """
    counter = 0
    while counter < len(cache):
        if cache[counter] != None:
            if request == cache[counter].page:
                return counter
        counter += 1
    return len(cache)

def find_LRU(cache):
    """
    Finds and returns entry of least recently used cache item.
    Also returns index of said item (both as a tuple)
    """
    oldestTime = 100000
    oldestEntryIndex = 0

    index = 0
    for entry in cache:
        if entry == None:
            pass
        
        if entry.time < oldestTime:
            oldestTime = entry.time
            oldestEntryIndex = index
        index += 1
        
    return(cache[oldestEntryIndex],oldestEntryIndex)

def run_LRU(cache, requests):
    missCount = 0
    time = 0
    for element in requests:
        print("Time: " + str(time), end = " ")
        print("Request: " + element, end = " ")
        
        """
        Tests if element is in cache
        """
        if position_in_cache(element, cache) == len(cache):
            print(" " + str(position_in_cache(element, cache)), end = " ")
            """
            MISS ACTIONS (request is not in cache)
            """
            victem = None
            if isCacheFull(cache) == False:
                """
                Puts element in cache if not contained and cache isn't full
                """
                put_in_cache(element, cache)
            else:
                """
                Replaces LRU with new element
                """
                victem = find_LRU(cache)
                cache[victem[1]] = LRUEntry(element,time)
            print("MISS. Victim:", end = " ")
            
            if victem == None:
                print("_", end = " ")
            elif victem[0] == None:
                print("_", end = " ")
            else:
                print(victem[0], end = " ")
                           
            missCount += 1
            print("Cache: " + str(cache))
        else:           
            """
            HIT ACTIONS (request is in cache)
            Update hit entry's time to current time
            """
            cache[position_in_cache(element, cache)].time = time
            print("HIT.")
        time += 1
        
    return missCount
    
def main():
    """
    Prompts for input, initializes and runs simulation
    Cache is 'full' when none of the values in it are 'None'
    """
    
    cache = []
    counter = 0
    count = int(input("Enter size of cache: "))
    while counter < count:
        cache.append(None)
        counter += 1
    request = input("Enter the string of memory requests: ")
    
    print("Least Recently Used (LRU) Algorithm")
    print("Cache size: " + str(len(cache)))
    print("Memory request string: " + request)
    
    """
    Runs algorithm and prints number of Misses
    """
    print("Miss Count: " + str(run_LRU(cache,request)))

main()

