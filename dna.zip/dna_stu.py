"""
Program with three basic DNA functions that are used in
conjunction with a test function for homework.

File: dna_stu.py
Author: Aaron Deever
Author: Brandon Calabrese
"""

from slList_stu import *

def constructDnaList(dnaString):
    """
    Given a DNA string, converts it into a list in which
    each character is a node.
    :param dnaString: string of DNA
    :return: dna string as a list
    """
    dnaList = createList()
    for char in dnaString:
        append(dnaList, char)
    return dnaList

def convertDnaListToString(lst):
    """
    Given a dna string in list form, convert back to string
    :param lst: dna list
    :return: dna as string
    """
    dnaString = ""
    counter = 0
    while counter < lst.size:
        dnaString += get(lst,counter)
        counter += 1
    return dnaString

def isPairing(lst1, lst2):
    """
    tests if the two strings are dna complementary base pairs.
    A must match with T, G with C.  Strings must be same length too.
    :param lst1: first dna list
    :param lst2: second dna list
    :return: boolean True if match, False else
    """

    if lst1.size == lst2.size:
        counter = 0
        while counter < lst1.size:
            value1 = get(lst1,counter)
            value2 = get(lst2,counter)
            
            if value1 == "A":
                if value2 != "T":
                    return False
            elif value1 == "T":
                if value2 != "A":
                    return False
            elif value1 == "G":
                if value2 != "C":
                    return False
            elif value1 == "C":
                if value2 != "G":
                    return False
            counter += 1
        return True
    else:
        return False
