"""
Sort - Brandon Calabrese
(used in Auto-Complete)
"""

"""
Swaps 2 values in a list
"""
def swap(lst, i, j):
    temp = lst[i]
    lst[i] = lst[j]
    lst[j] = temp

"""
Inserts smaller values in front of larger ones,
works with numbers as well as strings
"""
def insert(lst, mark):
    index = mark
    count = 0
    while index > -1 and lst[index] > lst[index + 1]:
        count += 1
        swap(lst, index, index + 1)
        index = index - 1
    return count
"""
Main sorting function, calls other functions
"""
def insertion_sort(lst):
    for mark in range(len(lst) - 1):
        insert(lst, mark)
    return lst

