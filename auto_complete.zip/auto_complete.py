"""
Auto-Complete - Brandon Calabrese
"""

from bsearch import binary_search
from sort import insertion_sort

"""
Returns False if prefix is longer than word being tested
"""
def testForPrefix(prefix, word):
    if len(prefix) > len(word):
        return False

    counter = 0
    for c in prefix:
        if c != word[counter]:
            return False
        counter += 1
    return True

"""
Grabs words from file, can take words from any number
of lines and seperates by at least one space
"""
def readFromFile(path):
    search = open(path)
    words = []
    for line in search:
        words += line.split()
    return words

"""
Finds words with the given prefix in an unordered list
in a linear methodology
"""
def findUnorderedWordsLinearly(words, prefix):
    matches = []
    for word in words:
        if testForPrefix(prefix, word):
            matches.append(word)
    return matches

"""
Finds words with the given prefix in an ordered list
in a linear methodology
"""
def findOrderedWordsLinearly(words, prefix):
    matches = []
    for word in words:
        if testForPrefix(prefix, word):
            matches.append(word)
    return matches

def main():
    """
    Grabs all word data
    """
    path = input("Enter the name of the known words file: ")
    unordered = readFromFile(path)
    ordered = unordered[:]
    ordered = insertion_sort(ordered)

    """
    Prints user instructions
    """
    print("The unsorted list: " + str(unordered))
    print("The sorted list: " + str(ordered))
    print("Welcome to Auto-complete!")
    print("Usage: Enter a prefix to auto-complete.")
    print("Entering nothing will search for the next word with that prefix.")
    print("Enter <QUIT> when asked for a prefix to exit.")

    prefix = ""
    oldPrefix = ""
    repeat = 0
    while prefix != "<QUIT>":
        """
        Lets the user input the prefix
        """
        prefix = input("Enter a prefix to be searched for: ")

        """
        Uses old prefix if empty string typed
        Also adds to number of repeats
        """
        if prefix == "":
            prefix = oldPrefix
            repeat += 1
        else:
            repeat = 0
            
        if prefix != "<QUIT>":
            """
            Uses 3 different functions to get word suggestions
            containing the given prefix
            """
            unorderedResults = findUnorderedWordsLinearly(unordered,prefix)
            orderedResults = findOrderedWordsLinearly(ordered,prefix)
            binaryResults = binary_search(ordered,prefix,0,len(ordered))

            """
            Sets repeat to number less than result list length
            to prevent out of range error
            """
            while repeat >= len(unorderedResults):
                repeat -= len(unorderedResults)

            """
            Prints results, different for each number of repeats.
            """
            print("Match for linear unsorted is " + str(unorderedResults[repeat]))
            print("Match for linear sorted is " + str(orderedResults[repeat]))
            print("Match for binary sorted is " + str(binaryResults[repeat]))
            
            oldPrefix = prefix
            print()
    print("Exiting Auto-complete! Good bye.")
main()





