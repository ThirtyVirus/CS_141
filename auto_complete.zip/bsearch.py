"""
bsearch - Brandon Calabrese
(used in Auto-Complete)
"""


"""
Tests if prefix is contained in word,
returns boolean value
"""
def testForPrefix(prefix, word):

    if len(prefix) > len(word):
        return False

    counter = 0
    for c in prefix:
        if c != word[counter]:
            return False
        counter += 1
    return True

"""
Searches through list of words in a binary way, also
counts forwards then backwards to grab values that
also have the given prefix.
"""
def binary_search(words, prefix, start, end):
    if start > end:
        return None
    """
    Outer parts of if statement searches for middlemost term
    with the prefix, then in the if statement grabs all
    applicable words before and after the center word.
    """
    mid_index = (start + end) // 2
    mid_value = words[mid_index]
    
    if testForPrefix(prefix,mid_value):
        
        start = mid_index
        end = mid_index

        """
        Searches for words with matching prfixed after middle word
        """
        counter = mid_index
        for word in range(mid_index, len(words)):
            if testForPrefix(prefix, words[counter]):
                end = counter + 1
            else:
                break
            counter += 1

        """
        Searches for words with matching prfixed before middle word
        """           
        counter = mid_index
        while(counter >= 0):
            if testForPrefix(prefix, words[counter]):
                start = counter
            counter -= 1
        """
        Returns all values that contain prefix in list
        """
        return words[start:end]
    
    elif prefix < mid_value:
        return binary_search(words, prefix, start, mid_index-1)
    else:
        return binary_search(words, prefix, mid_index+1, end)

