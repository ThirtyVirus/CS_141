"""
File Name: Volatility
Description: Calculates Volatility from certain data set,
prints data such as standard deviation
Author: Brandon Calabrese
Date: 11/20/16
"""

from indexTools import *
import math

"""Averages values given in nums and returns as float"""
def average(nums):
    avg = 0
    
    for n in nums:
        avg += n
    avg /= len(nums)
    return avg

"""Returns an array of float values representing the square of the deviations of the given data"""
def deviation_squared(nums, avg):
    lst = []
    
    for n in nums:
        lst.append(math.pow(n - avg,2))
    return lst

"""
Returns a list of (region, standard_deviation) tuples sorted from high to low values
Computes standard deviations using these values as the measure of volatility
"""
def measure_volatility(data):
    lst = []
   
    for key in data.keys():
        nums = []
        
        for element in data[key]:
            nums.append(element.index)
            
        avg = average(nums)
        devSquared = deviation_squared(nums, avg)

        devSum = 0
        for num in devSquared:
            devSum += num
        devSum /= len(data[key])
        stdev = math.sqrt(devSum)

        insert = (key, stdev)
        lst.append(insert)

    lst = sorted(lst, key=lambda x: x[1], reverse=True)    
    return lst

"""Prompts the user for input, interprets data differently depending on file, prints rankings based on standard deviation"""
def main():
    """
    Main docstring
    """
    filename = "data/" + input("Enter region-based house price index filename: ")
    region = input("Enter the region of interest: ")

    if "state.txt" in filename:
        data = read_state_house_price_data(filename)
    elif "ZIP5.txt" in filename:
        data = read_zip_house_price_data(filename)

    data = annualize(data)
    data = measure_volatility(data)
    print()
    print_ranking(data, "Annualized Price Standard Diviation, High to Low")
    print("\n" + "Note: Absence of data can increase the apparent variation")

    focus = ""
    for e in data:
        if e[0] == region:
            focus = e[1]
    if focus == "":
        print("Region " + str(region) + " not found.")
    else:
        print("Standard deviation for " + str(region) + " is " + str(focus))

"""Calls main only if file is run independantly"""
if __name__ == '__main__':
    main()
