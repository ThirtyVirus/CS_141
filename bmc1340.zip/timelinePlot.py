"""
File Name: TimelinePlot
Description: Graph changes in HPI values over time, both line and 'box and whiskers' graphs
Author: Brandon Calabrese
Date: 11/20/16
"""

from indexTools import *
import numpy.ma as ma
import matplotlib.ticker as mticker
import matplotlib.pyplot as plt
import datetime as dt
import matplotlib.dates as mdates
import copy

"""Creates graphable array from a list of AnnualHPI objects and a given set of years"""
def build_plottable_array(xyears, regionData):
    yaxis = []
    existingYears = []

    for element in regionData:
        existingYears.append(element.year)

    for year in xyears:
        if year in existingYears:
            for element in regionData:
                if element.year == year:
                    yaxis.append(element.index)
        else:
            yaxis.append(None)

    yaxis = ma.masked_array(yaxis)
    
    counter = 0
    while counter < len(yaxis):
        if yaxis[counter] == None:
            yaxis[counter] = ma.masked
        counter += 1
    
    return yaxis

"""Returns a dictionary only containing data between year0 and year1"""
def filter_years(data, year0, year1):
    newData = dict()

    for key in data.keys():
        for element in data[key]:
            if key in newData:
                if element.year >= year0 and element.year <= year1:
                    newData[key].append(element)
            else:
                newData[key] = []
    return newData

"""Graphs HPI data on line graph for given regions"""
def plot_HPI(data, regionList):
    year0 = data[regionList[0]][0].year
    year1 = data[regionList[0]][0].year

    for region in regionList:
        for element in data[region]:
            if element.year < year0:
                year0 = element.year
            elif element.year > year1:
                year1 = element.year

    years = []
    for i in range(year0, year1 + 1):
        years.append(i)

    for region in regionList:
        plt.plot(years,build_plottable_array(years, data[region]), "-*")

    plt.xticks(range(year0,year1, 2))
    plt.title("Home Price Indices: " + str(year0) + "-" + str(year1))
    plt.legend(regionList, loc = "upper left")
    plt.show()

"""Graphs HPI data on 'box and whisker' graph for given regions"""
def plot_whiskers(data, regionList):
    plt.title("Home Price Index Comparison. Median is a line. Mean is a square.")

    allData = []
    nums = []
              
    for region in regionList:
        yvals = []
        for element in data[region]:
            yvals.append(element.index)
        allData.append(yvals)
        nums.append(len(nums)+ 1)

    plt.boxplot(allData, showmeans = True)
    plt.xticks(nums,regionList)
    plt.show()

"""Takes in user input, then graphs data sets from file between two years. Calls graphing functions to do so."""
def main():
    """
    Main docstring
    """
    filename = "data/" + input("Please Enter File Name: ")   
    year0 = int(input("Enter the start year of the range to plot: "))
    year1 = int(input("Enter the end year of the range to plot: "))
    
    lst = []  
    while True:
        region = input("Next region of interest( Hit ENTER to stop): ")
        if region is not "":
            lst.append(region)
        else:
            break

    data = None
    if "state.txt" in filename:
        data = read_state_house_price_data(filename)
    elif "ZIP5.txt" in filename:
        data = read_zip_house_price_data(filename)
    data = annualize(data)
    data = filter_years(data, year0, year1)
    
    years = []
    for i in range(year0, year1):
        years.append(i)
        
    for i in lst:
        if "state.txt" in filename:
            print_range(data, i)

    print("Close display window to continue")
    plot_HPI(data, lst)
    print("Close display window to continue")
    plot_whiskers(data, lst)

"""Calls main only if file is run independantly"""
if __name__ == '__main__':
    main()
