"""
File Name: IndexTools
Description: Contains a set of utilities which includes
classes and functions used by the other program tasks.
Author: Brandon Calabrese
Date: 11/20/16
"""

from rit_lib import *

"""Defines the QuarterHPI data type, stores index values for a quarter of a year"""
class QuarterHPI(struct):
    _slots = ((int, 'year'),(int, 'qtr'),(float, 'index'))

"""Defines the AnnualHPI data type, stores index values for a single year"""
class AnnualHPI(struct):
    _slots = ((int, 'year'),(float, 'index'))

""""Retuns a dictionary mapping state abbreviations to lists of QuarterHPI objects"""
def read_state_house_price_data(filepath):
    file = open(filepath)
    data = dict()

    for line in file:
        line = line.strip()
        lineData = line.split("\t")
        
        if lineData[1].isdigit():
            if lineData[3] != ".":
                if lineData[0] not in data:
                    data[lineData[0]] = []
                data[lineData[0]].append(QuarterHPI(int(lineData[1]),int(lineData[2]),float(lineData[3])))           
            else:
                print("Data Unavailable: " + line)
                
    return data

"""Returns a dictionary mapping zip codes to lists of AnnualHPI objects"""
def read_zip_house_price_data(filepath):
    file = open(filepath)
    data = dict()
    counted = 0
    uncounted = 0

    for line in file:
        line = line.strip()
        lineData = line.split("\t")
        
        if lineData[1].isdigit():            
            if lineData[3] != ".":
                if lineData[0] not in data:
                    data[lineData[0]] = []
                data[lineData[0]].append(AnnualHPI(int(lineData[1]),float(lineData[3])))
                counted += 1
            else:
                uncounted += 1
        else:
            uncounted += 1

    print("Count: ", str(counted), " Uncounted: ", str(uncounted))
    return data

"""Returns a tuple of all HPI objects, the lowest and highest in a given dictionary and region"""
def index_range(data, region):
    lowest = data[region][0]
    highest = data[region][0]

    for i in data[region]:
        if i.index < lowest.index:
            lowest = i
        if i.index > highest.index:
            highest = i
    
    return (lowest, highest)

""""Prints the lowest and highest values (range) of the HPI for a specific region"""
def print_range(data, region):
    values = index_range(data, region)
    print("Region: ", str(region))
    if isinstance(values[0], QuarterHPI):
        print("Low: year/quarter/index: ", str(values[0].year), "/", str(values[0].qtr), "/", str(values[0].index))
        print("High: year/quarter/index: ", str(values[1].year), "/", str(values[1].qtr), "/", str(values[1].index))
    else:
        print("Low: year/index: ", str(values[0].year), "/", str(values[0].index))
        print("High: year/index: ", str(values[1].year), "/", str(values[1].index))

"""Prints a table of the top and bottom 10 (or less) HPIs from a given data set"""    
def print_ranking(data, heading="Ranking"):
    print(heading)

    counter = 0
    stop = len(data)
    if stop > 10:
        stop = 10
    print("The Top " + str(stop) + ":")
    while counter < stop:
        print(" " + str(counter + 1), ":", str(data[counter]))
        counter += 1
    counter = len(data) - stop
    print("The Bottom " + str(stop) + ":")
    stop = len(data)
    while counter < stop:
        print(" " + str(counter + 1), ":", str(data[counter]))
        counter += 1

"""Returns the index where a certain element comes up in lst, returns -1 if not there""" 
def containsYear(lst, element):
    counter = 0
    for i in lst:
        if i.year == element.year:
            return counter
        counter += 1
    return -1

"""Converts any HPI dataset to an AnnualHPI"""
def annualize(data):
    annual = dict()
    
    for key in data.keys():
        if key not in annual:
            annual[key] = []
            
        for element in data[key]:
            condition = containsYear(annual[key], element)
            if condition == -1:
                annual[key].append(AnnualHPI(element.year, element.index))
            else:
                annual[key][condition].index += element.index

    for key in data.keys():   
        year = data[key][0].year
        num = 0
        
        for element in data[key]:
            oldYear = year
            year = element.year
            if element.year == oldYear:
                num += 1
            else:
                for newElement in annual[key]:
                    if newElement.year == oldYear:
                        newElement.index /= num
                        num = 1
                           
    return annual

"""
Prompts the user for input, determines which way to interpret data, then prints
annualized version of data set in easy to read format
"""
def main():
    filename = "data/" + input("Enter house price index file: ")

    if "state.txt" in filename:
        data = read_state_house_price_data(filename)
    elif "ZIP5.txt" in filename:
        data = read_zip_house_price_data(filename)    
    
    print()
    regions = []
    while True:
        region = input("Next region of interest( Hit ENTER to stop): ")
        
        if region is not "":
            regions.append(region)      
        else:
            print("=" * 60)
            for r in regions:           
                print_range(data, r)
                data = annualize(data)
                print_range(data, r)
                print("Annualized Index Values for " + str(r))
                for element in data[r]:
                    print(element)
            break

"""Calls main only if file is run independantly"""
if __name__ == '__main__':
    main()








    
