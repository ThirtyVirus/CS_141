"""
File Name: PeriodRanking
Description: Computes the rankings of states or zip codes
for a given year, or for given year and a given quarter.
Author: Brandon Calabrese
Date: 11/20/16
"""

from indexTools import *

"""Returns a list of (region, HPI) tuples sorted from high to low HPI from given dataset, year, and quarter"""
def quarter_data(data, year, qtr):
    lst = []
    for key in data.keys():
        for element in data[key]:
            if element.year == year:
                if element.qtr == qtr:
                    new = (key, element.index)
                    lst.append(new)
    lst = sorted(lst, key=lambda x: x[1], reverse=True)
    return lst

"""Returns a list of (region, HPI) tuples sorted from high to low HPI from given dataset, year"""
def annual_data(data, year):
    lst = []
    for key in data.keys():
        for element in data[key]:
            if element.year == year:
                new = (key, element.index)
                lst.append(new)
    lst = sorted(lst, key=lambda x: x[1], reverse=True)

    return lst

"""Processes user input, chooses which way to interpret data, and prints rankings of values in data"""
def main():
    filename = "data/" + input("Enter region-based house price index filename: ")
    year = input("Enter year of interest for house prices: ")

    data = None
    if "state.txt" in filename:
        data = read_state_house_price_data(filename)
    elif "ZIP5.txt" in filename:
        data = read_zip_house_price_data(filename)  

    data = annualize(data)
    data = annual_data(data,int(year))

    print_ranking(data, "\n" + str(year) + " Annual Ranking")

"""Calls main only if file is run independantly"""
if __name__ == '__main__':
    main()
