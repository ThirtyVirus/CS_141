"""
File Name: Trending
Description: Computes the top and bottom trending regions based
on their growth between a given starting and ending year
Author: Brandon Calabrese
Date: 11/20/16
"""

from indexTools import *
import math

"""Returns a float representing the compound annual growth rate of the given index values in the specified region"""
def cagr(idxlist, periods):
    return (math.pow((idxlist[1]/idxlist[0]),1/periods) - 1) * 100

"""Returns a list of (region, rate) tuples sorted in descending order by the CAGR in dataset between year0 and year1"""
def calculate_trends(data, year0, year1):    
    lst = []
    for key in data.keys():
        currentCagr = (key, None, None)
        for element in data[key]:
            if element.year == year0:
                currentCagr = (key, element.index, currentCagr[2])
            if element.year == year1:
                currentCagr = (key, currentCagr[1], element.index)

        if currentCagr[1] != None and currentCagr[2] != None:
            i = (key, cagr((currentCagr[1], currentCagr[2]), year1-year0))
            lst.append(i)

    lst = sorted(lst, key=lambda x: x[1], reverse=True)
    return lst

"""Prompts user for input, prints rankings of data in certain dataset between start and end"""
def main():
    """
    Main docstring
    """
    filename = "data/" + input("Enter house price index filename: ")
    start = int(input("Enter start year of interest: "))
    end = int(input("Enter ending year of interest: "))

    data = None
    if "state.txt" in filename:
        data = read_state_house_price_data(filename)
    elif "ZIP5.txt" in filename:
        data = read_zip_house_price_data(filename)  
    
    data = annualize(data)
    data = calculate_trends(data, start, end)

    print_ranking(data, "\n" + str(start) + "-" + str(end) + " Compound Annual Growth Rate")

"""Calls main only if file is run independantly"""      
if __name__ == '__main__':
    main()
