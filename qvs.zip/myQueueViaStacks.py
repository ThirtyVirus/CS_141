from rit_lib import *
from myNode import *
from myStack import *

"""
Defines a Queue using two Stacks
"""
class QueueViaStacks(struct):
    _slots = ((Stack, "stack1"), (Stack, "stack2"), (int, "size"))

"""
Creates a GueueViaStacks
"""
def createQVS():
    return QueueViaStacks(Stack(None,0),Stack(None,0),0)

"""
Adds an element to the back of the Queue
"""
def enqueue(queue, element):
    while queue.stack1.size > 0:
        push(queue.stack2, top(queue.stack1))    
        pop(queue.stack1)
        
    push(queue.stack2,element)

    while queue.stack2.size > 0:
        push(queue.stack1, top(queue.stack2))    
        pop(queue.stack2)
    queue.size += 1

"""
Removes the frontmost element from the queue
"""
def dequeue(queue):
    pop(queue.stack1)
    queue.size -= 1

"""
Returns the first element in the queue
"""
def front(queue):
    return top(queue.stack1)

"""
Returns the last element in the queue
"""
def back(queue):    
    while queue.stack1.size > 0:
        push(queue.stack2, top(queue.stack1))    
        pop(queue.stack1)
    
    backElement = top(queue.stack2)
    
    while queue.stack2.size > 0:
        push(queue.stack1, top(queue.stack2))    
        pop(queue.stack2)
        
    return backElement

"""
Returns a boolean if the Queue is empty or not
"""
def emptyQueue(queue):
    if queue.stack1.size == 0:
        return True
    return False
