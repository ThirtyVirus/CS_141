"""
description: open addressing Hash Table for CS 141 Lecture
file: hashtable.py
language: python3
author: sps@cs.rit.edu Sean Strout
author: jeh@cs.rit.edu James Heliotis
author: anh@cs.rit.edu Arthur Nunes-Harwitt
author: jsb@cs.rit.edu Jeremy Brown
author: as@cs.rit.edu Amar Saric
author: scj@cs.rit.edu Scott Johnson
           -- Added the hash function as a slot to the hash table
           -- Added a capacity slot in the hash table
author: Brandon Calabrese
"""

from rit_lib import *

class HashTable(struct):
    """
           The HashTable data structure contains a collection of values
       where each value is located by a hashable key.
       No two values may have the same key, but more than one
       key may have the same value.
       table is the list holding the hash table
       size is the number of elements in occupying the hashtable

    """
    _slots = ((list, 'table'), (int, 'size'), (int, 'capacity'), (object, 'hash_func'))

def hash_function(element):
    total = 0
    counter = 0
    for c in element:
        total += ord(c) * 31**counter
        counter += 1
    return total

def createHashTable(hash_func, capacity=100):
    """
    createHashTable: NatNum? -> HashTable
    """
    table = []
    counter = 0
    while counter < capacity:
        table.append([])
        counter += 1
    return HashTable(table,0,capacity,hash_func)

def resizeHashTable(hTable):
    """
    HashTableToStr: HashTable -> None
    
    Doubles the size of the table.
    """ 
    return createHashTable(hTable.hash_func, hTable.capacity * 2 + 1)

def HashTableToStr(hashtable):
    """
    HashTableToStr: HashTable -> String
    """
    result = ""
    for lst in hashtable.table:
        for element in lst:
            result += EntryToStr(element) + ", "
        result += "\n"
        
    return result


class Entry(struct):
    """
       A class used to hold key/value pairs.
    """

    _slots = ((object, "key"), (object, "value"))


def EntryToStr(entry):
    """
    EntryToStr: Entry -> String
    return the string representation of the entry.
    """
    return "(" + str(entry.key) + ", " + str(entry.value) + ")"
    
def imbalance(hTable):
    """
    keys: HashTable(K, V) -> Num
    
    Computes the imbalance of the hashtable.
    """
    totalNum = 0
    total = 0
    for lst in hTable.table:
        if len(lst) > 0:
            total += len(lst)
            totalNum += 1
    total /= totalNum
    total -= 1
    return total

def keys(hTable):
    """
    keys: HashTable(K, V) -> List(K)
    Return a list of keys in the given hashTable.
    """
    result = []
    for entry in hTable.table:
        if entry != None:
            for entry2 in entry:
                if entry2 != None:
                    result.append(entry2.key)
    return result

def has(hTable, key):
    """
    has: HashTable(K, V) K -> Boolean
    Return True iff hTable has an entry with the given key.
    """
    
    index = hTable.hash_func(key) % hTable.capacity

    for element in hTable.table[index]:
        if element.key == key:
            return True
    return False

def put(hTable, key, value):
    """
    put: HashTable(K, V) K V -> Boolean

    Using the given hash table, set the given key to the
    given value. If the key already exists, the given value
    will replace the previous one already in the table.
    If the table is full, an Exception is raised.
    """
    load = 0
    for lst in hTable.table:
        load += len(lst)
    load /= hTable.capacity

    if load > 0.75:
        newTable = resizeHashTable(hTable)
        for lst in hTable.table:
            for element in lst:
                i = newTable.hash_func(key) % newTable.capacity
                newTable.table[i].append(element)
                newTable.size += 1
    
    index = hTable.hash_func(key) % hTable.capacity
    for element in hTable.table[index]:
        if element.key == key:
            element.value += 1
            return
    hTable.table[index].append(Entry(key, value))
    hTable.size += 1

def get(hTable, key):
    """
    get: HashTable(K, V) K -> V

    Return the value associated with the given key in
    the given hash table.

    Precondition: has(hTable, key)
    """
    index = hTable.hash_func(key) % hTable.capacity

    for element in hTable.table[index]:
        if element.key == key:
            return element.value
    return None

def remove(hTable, key):
    """
    remove: HashTable(K, V) K -> V

    Removes specified element from Hash Table

    Precondition: has(hTable, key)
    """
    index = hTable.hash_func(key) % hTable.capacity
    for element in hTable.table[index]:
        if element.key == key:
            hTable.table[index].remove(element)
            hTable.size -= 1
            return
    return None
