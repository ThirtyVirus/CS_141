"""
Balanaced_bst Homework #10 Brandon Calabrese
"""

import random
from rit_lib import *
import math

"""Defines the class that describes a binary tree"""
class BinaryTree(struct):
    _slots = (((NoneType, 'BinaryTree'), 'left'), (object, 'value'), ((NoneType, 'BinaryTree'), 'right'))

"""Returns a tree containing a value 'data' and left and right slots for more trees or None"""
def create_tree(data, left=None, right=None):
    return BinaryTree(left, data, right)

"""Returns a tree 'bst' from a list of sorted numbers"""
def balanced_bst_tree_from_list(lst):
    if len(lst) == 0:
        return None
    if len(lst) == 1:
        return create_tree(lst[0], None, None)
    
    index = int(len(lst)//2)

    h1 = []
    counter = 0
    while counter < index:
        h1.append(lst[counter])
        counter += 1
    h2 = []
    counter = index + 1
    while counter < len(lst):
        h2.append(lst[counter])
        counter += 1

    return create_tree(lst[index], balanced_bst_tree_from_list(h1), balanced_bst_tree_from_list(h2))

"""Returns a sorted list of the elements contained in a tree"""
def in_order_traverse(bst):
    if bst == None:
        return None
    elif isinstance(bst, BinaryTree):
        lst = []
        
        h1 = in_order_traverse(bst.left)
        if h1 != None:
            lst += h1
            
        lst.append(bst.value)
        
        h2 = in_order_traverse(bst.right)
        if h2 != None:
            lst += h2
            
        return lst

"""Returns the height of tree 'bst'"""
def tree_height(bst):
    num = len(in_order_traverse(bst))
    height = -1
    goal = 1

    while num > 0:
        counter = 0
        while counter < goal:
            counter += 1
        height += 1
        num -= goal
        goal *= 2
    return height

"""Creates list of 'size' length populated with numbers from -1000 to 1000"""
def createRandList(size):
    lst = []
    counter = 0
    while counter < size:
        lst.append(random.randint(-1000,1000))
        counter += 1
    return lst

"""Prompts user for input, calls other functions, and displays results"""
def main():
    size = str(input("Enter size: "))
    if str(size).isdigit() == False:
        print("Usage: run python3 balanced_bst.py and enter a non-negative integer")
        return
    elif int(size) < 0:
        print("Usage: run python3 balanced_bst.py and enter a non-negative integer")
        return
    size = int(size)
    
    print("Entered: " + str(size))
    data = createRandList(size)
    
    print("Number List: " + str(data))
    data.sort()
    print("Sorted List: " + str(data))

    balancedBST = balanced_bst_tree_from_list(data)
    
    print("In Order Traversal:")  
    print(in_order_traverse(balancedBST))
    
    print("Height: " + str(tree_height(balancedBST)))

    if size == 0:
        print("Log2 of N is: Undefined")
    else:
        print("Log2 of N is: " + str(math.log2(size)))
main()
