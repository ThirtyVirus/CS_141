from rit_lib import *
"""
Brandon Calabrese - dlNode, for use with hot potato
"""

"""Defines the nodes used in the linked lists"""
class Node(struct):
    _slots = ((str,'data'),((NoneType, 'Node'),'prev'),((NoneType, 'Node'),'next'))
