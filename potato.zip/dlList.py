from dlNode import *

"""
Brandon Calabrese - dlList, for use with hot potato
"""

"""Defines the CDlists containing the nodes"""
class CDList(struct):
    _slots = (((NoneType, Node), 'potato'), (int, 'size'))

"""Creates an empty SDList"""
def createCDList():
    return CDList(None,0)  

"""Adds a player to the CDlist"""
def addPlayer(playerList, player):
    if playerList.size == 0:
        playerList.potato = player
    elif playerList.size == 1:
        playerList.potato.prev = player
        playerList.potato.next = player

        player.prev = playerList.potato
        player.next = playerList.potato     
    else:
        player.next = playerList.potato
        player.prev = playerList.potato.prev

        playerList.potato.prev.next = player
        playerList.potato.prev = player
          
    playerList.size += 1

"""Removes a player from the CDlist"""
def removePlayer(playerList, player, clockwise):
    playerList.potato.prev.next = playerList.potato.next
    playerList.potato.next.prev = playerList.potato.prev

    if clockwise:
        playerList.potato = playerList.potato.next       
    else:
        playerList.potato = playerList.potato.prev
    
    playerList.size -= 1

"""Prints the contents of the CDlist"""
def displayCDList(CDList):
    currentNode = CDList.potato

    counter = 0
    while counter < CDList.size - 1:
        print(str(currentNode.data) + ",", end = " ")
        currentNode = currentNode.next
        counter += 1
    print(str(currentNode.data))
