from dlList import *
import random
"""
Brandon Calabrese - Hot Potato
"""

"""Produces a list of Pokemon from a file"""
def getContestants(path):
    players = createCDList()
    data = open(path)
    for line in data:
        addPlayer(players,Node(line.rstrip(),None,None))
    return players

"""Passes the potato in a circle"""
def passPotato(players, passNumber):
    print("The music starts (" + str(passNumber) + "):", end = " ")
    currentNode = players.potato

    loopNum = abs(passNumber)
    counter = 0
    while counter < loopNum:
        print(str(currentNode.data) + " -> ", end = " ")

        if passNumber >= 0:           
            currentNode = currentNode.next
        else:
            currentNode = currentNode.prev
        
        counter += 1
    print(str(currentNode.data) + " is stuck holding the potato!")
    players.potato = currentNode
    removePlayer(players, players.potato, passNumber >= 0)

"""Simulates the hot potato game"""
def hotPotato(players, seed):
    random.seed(int(seed))
    
    while players.size > 1:
        potatoPasses = random.randint(-2*players.size, 2*players.size)
        passPotato(players,potatoPasses)
     
        if players.size == 1:
            print(str(players.potato.data) + " is the winner!")
            return
"""Gets user input and calls game simulation"""
def main():
    print("Welcome to the Hot Potato Game!")
    path = input("Enter a file of contestants: ")   
    seed = input("Enter a seed number for random number generator: ")
    
    print("Ready to play Hot Potato. Contestants are: ")
    players = getContestants(path)
    displayCDList(players)
    hotPotato(players, seed)
    
main()
